package com.SchoolProjectIDM.Project.model

data class Orders(var id: Int, var Prato: String, var Nome: String, var Morada: String, var foiEntregue : Boolean)