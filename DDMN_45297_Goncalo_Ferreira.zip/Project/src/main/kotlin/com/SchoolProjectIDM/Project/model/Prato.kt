package com.SchoolProjectIDM.Project.model

data class Prato(var id: Int, var nome: String, var preco: Double)